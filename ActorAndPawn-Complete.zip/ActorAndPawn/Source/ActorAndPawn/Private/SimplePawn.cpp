// Fill out your copyright notice in the Description page of Project Settings.


#include "SimplePawn.h"
#include "PaperSpriteComponent.h"
#include "GameFramework/SpringArmComponent.h"
#include "Camera/CameraComponent.h"
#include "SimplePawnMovementComponent.h"
// Sets default values
ASimplePawn::ASimplePawn()
{
 	// Set this pawn to call Tick() every frame.  You can turn this off to improve performance if you don't need it.
	PrimaryActorTick.bCanEverTick = true;

	PlayerRoot = CreateDefaultSubobject<USceneComponent>("Player Root");
	SetRootComponent(PlayerRoot);
	//OR
	//RootComponent = PlayerRoot;

	PawnSpriteComponent = CreateDefaultSubobject<UPaperSpriteComponent>("Pawn Sprite");
	PawnSpriteComponent->SetupAttachment(RootComponent);//Attach to RootComponent

	SpringArm = CreateDefaultSubobject<USpringArmComponent>(TEXT("CameraAttachmentArm"));
	SpringArm->SetupAttachment(RootComponent);//Attach to RootComponent
	//Set SpringArm Properties
	SpringArm->SetRelativeRotation(FRotator(0.f, -90.f, 0.f));
	SpringArm->SocketOffset = FVector(0.0f, 0.0f, 300.0f);
	SpringArm->TargetArmLength = 500.0f;
	SpringArm->bEnableCameraLag = true;
	SpringArm->CameraLagSpeed = 10.0f;

	FollowCamera = CreateDefaultSubobject<UCameraComponent>("Pawns Camera");
	FollowCamera->SetupAttachment(SpringArm);//Attach to SpringArm
	FollowCamera->SetProjectionMode(ECameraProjectionMode::Orthographic);
	FollowCamera->SetOrthoWidth(5000.0f);
	FollowCamera->bUsePawnControlRotation = false;

	//Auto possess the Pawnand Receive Player0's Input.
	AutoPossessPlayer = EAutoReceiveInput::Player0;

	//Create the SimplePawnMovementComponent
	SimplePawnMovementComponent = CreateDefaultSubobject<USimplePawnMovementComponent>(TEXT("CustomMovementComponent"));
	//Set the SimplePawnMovementComponent's UpdateComponent to the RootComponent. This will apply the movement to the RootComponent
	SimplePawnMovementComponent->UpdatedComponent = RootComponent;
}

// Called when the game starts or when spawned
void ASimplePawn::BeginPlay()
{
	Super::BeginPlay();
	
}

// Called every frame
void ASimplePawn::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);
	if (bSpin)
	{
		// on every frame change rotation for a smooth rotating actor
		FQuat QuatRotation = FRotator(0, 10, 0).Quaternion();

		PawnSpriteComponent->AddLocalRotation(QuatRotation, false, 0, ETeleportType::None);
	}
}

// Called to bind functionality to input
void ASimplePawn::SetupPlayerInputComponent(UInputComponent* PlayerInputComponent)
{
	Super::SetupPlayerInputComponent(PlayerInputComponent);
	//Bind the Input Command FlyRight, to this Object. When FlyRight is Pressed we call the Function MoveForward()
	PlayerInputComponent->BindAxis("FlyRight", this, &ASimplePawn::MoveForward);
	//Bind the Input Command FlyUp, to this Object. When FlyRight is Pressed we call the Function MoveUp()
	PlayerInputComponent->BindAxis("FlyUp", this, &ASimplePawn::MoveUp);

	//Bind the Input Action SpinToggle when The button is Pressed to this object. When the SpinToggle Action is pressed it will call SpinToggle()
	PlayerInputComponent->BindAction("SpinToggle", IE_Pressed, this, &ASimplePawn::SpinToggle);
	//Bind the Input Action SpinToggle when The button is Released to this object. When the SpinToggle Action is pressed it will call SpinToggle()
	PlayerInputComponent->BindAction("SpinToggle", IE_Released, this, &ASimplePawn::SpinToggle);
}

void ASimplePawn::MoveForward(float AxisValue)
{
	MovementForward = AxisValue;
	if (SimplePawnMovementComponent && (SimplePawnMovementComponent->UpdatedComponent == RootComponent))
	{
		//Move the Pawn using the SimplePawnMovementComponent on the Forward Vector
		SimplePawnMovementComponent->AddInputVector(GetActorForwardVector() * -MovementForward * 1000);

	}
	//Rotate the PawnSprite
	if (MovementForward > 0)
		PawnSpriteComponent->SetRelativeRotation(FRotator(0, AxisValue * 180, 0));

	//Rotate the PawnSprite
	if (MovementForward < 0)
		PawnSpriteComponent->SetRelativeRotation(FRotator(0, 0, 0));
}

void ASimplePawn::MoveUp(float AxisValue)
{
	MovementUp = AxisValue;
	if (SimplePawnMovementComponent && (SimplePawnMovementComponent->UpdatedComponent == RootComponent))
	{
		//Move the Pawn using the SimplePawnMovementComponent on the Up Vector
		SimplePawnMovementComponent->AddInputVector(GetActorUpVector() * MovementUp * 1000);
	}
	//Rotate the PawnSprite
	if (MovementUp > 0)
		PawnSpriteComponent->SetRelativeRotation(FRotator(0, 0, MovementUp * 180));
	//Rotate the PawnSprite
	if (MovementUp < 0)
		PawnSpriteComponent->SetRelativeRotation(FRotator(270, 0, 0));
}

void ASimplePawn::SpinToggle()
{
	//Toggle the bSpin boolean
	bSpin = !bSpin;
}

